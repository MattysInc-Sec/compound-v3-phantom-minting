# Compound Comet Exploit PoC

## Network
Mainnet fork (Compound v3 Comet)  
Solidity 0.8.13

## Steps
1. Deploy FakeToken.sol with a transferFrom() that always returns true
2. Approve Comet to spend the token
3. Call supplyTo(attacker, fakeToken, 1e18)
4. Observe: totalsSupply and balanceOf are inflated without any real asset movement
5. Repeatable attack – can simulate large phantom supply

## Impact
- Fake balanceOf in protocol
- Artificial totalsSupply inflation
- Potential protocol insolvency if withdraw() is also vulnerable

## Files
- FakeToken.sol
- Exploit.sol
